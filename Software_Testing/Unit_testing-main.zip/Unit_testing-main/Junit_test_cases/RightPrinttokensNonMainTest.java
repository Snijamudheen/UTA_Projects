package non_main_test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.IOException;
import java.io.PrintStream;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class RightPrinttokensNonMainTest {

    static right_printtokens ob;

    @BeforeAll
    static void initialize() throws IOException {
        ob = new right_printtokens();
    }

    @Test
    void is_keyword_test() {
        assertTrue(right_printtokens.is_keyword("and"));
        assertTrue(right_printtokens.is_keyword("or"));
        assertTrue(right_printtokens.is_keyword("if"));
        assertTrue(right_printtokens.is_keyword("xor"));
        assertTrue(right_printtokens.is_keyword("lambda"));
        assertTrue(right_printtokens.is_keyword("=>"));
        assertFalse(right_printtokens.is_keyword("software"));
        assertFalse(right_printtokens.is_keyword("lambda1"));
    }

    @Test
    void is_num_constant_test() {
        assertFalse(right_printtokens.is_num_constant("a"));
        assertFalse(right_printtokens.is_num_constant("1A"));
        assertTrue(right_printtokens.is_num_constant("123"));
        assertTrue(right_printtokens.is_num_constant("1"));
        assertTrue(right_printtokens.is_num_constant("321\0"));
        assertFalse(right_printtokens.is_num_constant("-123"));
        assertFalse(right_printtokens.is_num_constant("1.23"));
    }

    @Test
    void get_char_test() {
        Reader temp = new StringReader("test");
        BufferedReader br = new BufferedReader(temp);
        try {
            assertEquals('t', ob.get_char(br));
            assertEquals('e', ob.get_char(br));
            assertEquals('s', ob.get_char(br));
            assertEquals('t', ob.get_char(br));
            assertEquals(-1, ob.get_char(br)); // EOF
        } catch (Exception e) {
            // Handle the exception without printing stack trace
        }
    }

    @Test
    void is_str_constant_test() {
        assertFalse(right_printtokens.is_str_constant("21"));
        assertTrue(right_printtokens.is_str_constant("\"\""));
        assertTrue(right_printtokens.is_str_constant("\"cse\"\0"));
        assertFalse(right_printtokens.is_str_constant("\"D"));
        assertFalse(right_printtokens.is_str_constant("\"S\0"));
        assertFalse(right_printtokens.is_str_constant("\""));
        assertFalse(right_printtokens.is_str_constant("\"string"));
        assertTrue(right_printtokens.is_str_constant("\"string\""));
    }

    @Test
    void is_identifier_test() {
        assertFalse(right_printtokens.is_identifier("1"));
        assertFalse(right_printtokens.is_identifier("a!"));
        assertTrue(right_printtokens.is_identifier("aa"));
        assertTrue(right_printtokens.is_identifier("a1\0"));
        assertFalse(right_printtokens.is_identifier("_identifier"));
        assertFalse(right_printtokens.is_identifier("identifier!"));
    }

    @Test
    void token_type_test() {
        assertEquals(right_printtokens.keyword, right_printtokens.token_type("and"));
        assertEquals(right_printtokens.spec_symbol, right_printtokens.token_type("("));
        assertEquals(right_printtokens.identifier, right_printtokens.token_type("cse4321"));
        assertEquals(right_printtokens.num_constant, right_printtokens.token_type("123"));
        assertEquals(right_printtokens.str_constant, right_printtokens.token_type("\"str\""));
        assertEquals(right_printtokens.char_constant, right_printtokens.token_type("#a"));
        assertEquals(right_printtokens.comment, right_printtokens.token_type("; comment"));
        assertEquals(right_printtokens.error, right_printtokens.token_type("!@#"));
    }

    @Test
    void print_token_test() {
        // Redirect System.out for testing
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        ob.print_token("and");
        assertEquals("keyword,\"and\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("(");
        assertEquals("lparen.", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("cse4321");
        assertEquals("identifier,\"cse4321\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("123");
        assertEquals("numeric,123.", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("\"str\"");
        assertEquals("string,\"str\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("#a");
        assertEquals("character,\"a\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("; comment");
        assertEquals("comment,\"; comment\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("!@#");
        assertEquals("error,\"!@#\".", outContent.toString().trim());
    }

    @Test
    void unget_char_test() {
        Reader temp = new StringReader("test");
        BufferedReader br = new BufferedReader(temp);
        try {
            assertEquals('t', ob.get_char(br));
            assertEquals('e', ob.get_char(br));
            ob.unget_char('e', br);
            assertEquals('e', ob.get_char(br)); // Should read 'e' again after unget
        } catch (Exception e) {
            // Handle the exception without printing stack trace
        }
    }

    @Test
    void get_token_test() {
        Reader temp = new StringReader("");
        BufferedReader br = new BufferedReader(temp);
        assertEquals(null, ob.get_token(br));

        temp = new StringReader("\t");
        br = new BufferedReader(temp);
        assertEquals("\t", ob.get_token(br));

        temp = new StringReader("\n");
        br = new BufferedReader(temp);
        assertEquals(null, ob.get_token(br));

        temp = new StringReader("\r");
        br = new BufferedReader(temp);
        assertEquals(null, ob.get_token(br));

        temp = new StringReader("(");
        br = new BufferedReader(temp);
        assertEquals("(", ob.get_token(br));

        temp = new StringReader("\nb");
        br = new BufferedReader(temp);
        assertEquals("b", ob.get_token(br));

        temp = new StringReader(";");
        br = new BufferedReader(temp);
        assertEquals(";", ob.get_token(br));

        temp = new StringReader("\"");
        br = new BufferedReader(temp);
        assertEquals("\"", ob.get_token(br));

        temp = new StringReader("XY ");
        br = new BufferedReader(temp);
        assertEquals("XY", ob.get_token(br));

        temp = new StringReader("CSE");
        br = new BufferedReader(temp);
        assertEquals("CSE", ob.get_token(br));

        temp = new StringReader("CSE(");
        br = new BufferedReader(temp);
        assertEquals("CSE", ob.get_token(br));

        temp = new StringReader("CSE\"");
        br = new BufferedReader(temp);
        assertEquals("CSE\"", ob.get_token(br));

        temp = new StringReader("CSE;");
        br = new BufferedReader(temp);
        assertEquals("CSE", ob.get_token(br));

        temp = new StringReader("CSE");
        br = new BufferedReader(temp);
        assertEquals("CSE", ob.get_token(br));

        temp = new StringReader("\"CSE\"");
        br = new BufferedReader(temp);
        assertEquals("\"CSE\"", ob.get_token(br));

        temp = new StringReader("#a");
        br = new BufferedReader(temp);
        assertEquals("#a", ob.get_token(br));

    }

    @Test
    void is_token_end_test() {
        // Testing with state 0 (start state)
        assertEquals(true, right_printtokens.is_token_end(0, -1), "State 0, char -1 should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 10), "State 0, char 10 (newline) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 13),
                "State 0, char 13 (carriage return) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 32), "State 0, char 32 (space) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 40),
                "State 0, char 40 (open parenthesis) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 59), "State 0, char 59 (semicolon) should be token end");
        assertEquals(false, right_printtokens.is_token_end(0, 69), "State 0, char 69 should not be token end");

        // Testing with state 1 (inside token state)
        assertEquals(true, right_printtokens.is_token_end(1, 34),
                "State 1, char 34 (double quote) should be token end");
        assertEquals(true, right_printtokens.is_token_end(1, 10), "State 1, char 10 (newline) should be token end");
        assertEquals(true, right_printtokens.is_token_end(1, 13),
                "State 1, char 13 (carriage return) should be token end");
        assertEquals(false, right_printtokens.is_token_end(1, 67), "State 1, char 67 should not be token end");

        // Testing with state 2 (inside string state)
        assertEquals(true, right_printtokens.is_token_end(2, 10), "State 2, char 10 (newline) should be token end");
        assertEquals(true, right_printtokens.is_token_end(2, 13),
                "State 2, char 13 (carriage return) should be token end");
        assertEquals(true, right_printtokens.is_token_end(2, 9), "State 2, char 9 (tab) should be token end");
        assertEquals(false, right_printtokens.is_token_end(2, 68), "State 2, char 68 should not be token end");

        // Adjusted edge case to match the actual behavior
        assertEquals(false, right_printtokens.is_token_end(0, 0),
                "State 0, char 0 (null character) should not be token end");
        assertEquals(false, right_printtokens.is_token_end(1, 48), "State 1, char 48 (number) should not be token end");
        assertEquals(false, right_printtokens.is_token_end(2, 65), "State 2, char 65 (letter) should not be token end");
    }

    @Test
    void open_character_stream_test() {
        BufferedReader br = ob.open_character_stream(null);
        assertNotNull(br);

        br = ob.open_character_stream("");
        assertNotNull(br);

        br = ob.open_character_stream("nonexistentfile.txt");
        assertNull(br); // Ensure this returns null for non-existent file

        // Create a temporary file for testing
        File tempFile = null;
        try {
            tempFile = File.createTempFile("testfile", ".txt");
            FileWriter writer = new FileWriter(tempFile);
            writer.write("sample content");
            writer.close();

            br = ob.open_character_stream(tempFile.getAbsolutePath());
            assertNotNull(br);
        } catch (IOException e) {
            // Handle the exception without printing stack trace
        } finally {
            if (tempFile != null) {
                tempFile.delete();
            }
        }
    }

    @Test
    void open_token_stream_test() {
        BufferedReader br = ob.open_token_stream(null);
        assertNotNull(br);

        br = ob.open_token_stream("");
        assertNotNull(br);

        br = ob.open_token_stream("nonexistentfile.txt");
        assertNull(br); // Ensure this returns null for non-existent file

        // Create a temporary file for testing
        File tempFile = null;
        try {
            tempFile = File.createTempFile("testfile", ".txt");
            FileWriter writer = new FileWriter(tempFile);
            writer.write("sample content");
            writer.close();

            br = ob.open_token_stream(tempFile.getAbsolutePath());
            assertNotNull(br);
        } catch (IOException e) {
            // Handle the exception without printing stack trace
        } finally {
            if (tempFile != null) {
                tempFile.delete();
            }
        }
    }

    @Test
    void is_spec_symbol_test() {
        assertTrue(right_printtokens.is_spec_symbol('('));
        assertTrue(right_printtokens.is_spec_symbol(')'));
        assertTrue(right_printtokens.is_spec_symbol('['));
        assertTrue(right_printtokens.is_spec_symbol(']'));
        assertTrue(right_printtokens.is_spec_symbol('\''));
        assertTrue(right_printtokens.is_spec_symbol('`'));
        assertTrue(right_printtokens.is_spec_symbol(','));
        assertTrue(right_printtokens.is_spec_symbol('/'));
        assertFalse(right_printtokens.is_spec_symbol('a'));
        assertFalse(right_printtokens.is_spec_symbol('1'));
    }

    @Test
    void print_spec_symbol_test() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        right_printtokens.print_spec_symbol("(");
        assertEquals("lparen.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol(")");
        assertEquals("rparen.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("[");
        assertEquals("lsquare.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("]");
        assertEquals("rsquare.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("'");
        assertEquals("quote.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("/");
        assertEquals("slash.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("`");
        assertEquals("bquote.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol(",");
        assertEquals("comma.", outContent.toString().trim());
    }

    @Test
    void print_token_special_symbol_test() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        ob.print_token("(");
        assertEquals("lparen.", outContent.toString().trim());

        outContent.reset();
        ob.print_token(")");
        assertEquals("rparen.", outContent.toString().trim());

        outContent.reset();
        ob.print_token("[");
        assertEquals("lsquare.", outContent.toString().trim());

        outContent.reset();
        ob.print_token("]");
        assertEquals("rsquare.", outContent.toString().trim());

        outContent.reset();
        ob.print_token("'");
        assertEquals("quote.", outContent.toString().trim());

        outContent.reset();
        ob.print_token("/");
        assertEquals("slash.", outContent.toString().trim());

        outContent.reset();
        ob.print_token("`");
        assertEquals("bquote.", outContent.toString().trim());

        outContent.reset();
        ob.print_token(",");
        assertEquals("comma.", outContent.toString().trim());
    }
}
