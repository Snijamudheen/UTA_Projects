package main_test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.BufferedReader;
import java.io.StringReader;
import java.nio.file.Files;

class RightPrinttokensMainTest {

    static ByteArrayOutputStream output;
    static right_printtokens ob;

    @BeforeAll
    static void setup() {
        output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output)); // Set default System.out
        ob = new right_printtokens();
    }

    @Test
    public void testInvalidArguments() throws IOException {
        output.reset();

        // Print debug information before running the main method
        System.out.println("Setting up invalid arguments test.");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Run the main method with invalid arguments
        String[] args = { "file.txt", "file2.txt" };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim();
        System.out.println("Captured output: [" + actual + "]");

        // Expected output
        String expected = "Error! Please give the token stream"; // Updated expected output
        System.out.println("Expected output: [" + expected + "]");

        // Assert the expected output
        assertEquals(expected, actual);
    }

    @Test
    public void testEmptyFile() throws IOException {
        output.reset();

        // Create a temporary empty file
        File tempFile = File.createTempFile("emptyFile", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("");
        writer.close();

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        String actual = output.toString().trim();
        String expected = "";
        System.out.println("Actual: " + actual);
        assertEquals(expected, actual);

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testFileWithTokens() throws IOException {
        output.reset();

        // Create a temporary file with the specific content
        File tempFile = File.createTempFile("testFile", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("hello world\n" +
                "foo bar baz\n" +
                "123 456 789\n" +
                "\"test string\" 'single quotes'\n" +
                "#hash tag /slash\n");
        writer.close();

        // Print debug information about the file
        System.out.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.out.println("Temporary file content: " + new String(Files.readAllBytes(tempFile.toPath())));

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Read the output
        String actual = baos.toString().trim().replace("\r\n", "\n");

        // Remove the debug line from the actual output
        String[] lines = actual.split("\n");
        StringBuilder filteredOutput = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            if (!lines[i].startsWith("Calling right_printtokens.main with args:")) {
                filteredOutput.append(lines[i]);
                if (i < lines.length - 1) {
                    filteredOutput.append("\n");
                }
            }
        }

        String filteredActual = filteredOutput.toString();
        String expected = "identifier,\"hello\".\n" +
                "identifier,\"world\".\n" +
                "identifier,\"foo\".\n" +
                "identifier,\"bar\".\n" +
                "identifier,\"baz\".\n" +
                "numeric,123.\n" +
                "numeric,456.\n" +
                "numeric,789.\n" +
                "string,\"test string\".\n" +
                "quote.\n" +
                "identifier,\"single\".\n" +
                "identifier,\"quotes\".\n" +
                "quote.\n" +
                "error,\"#hash\".\n" +
                "identifier,\"tag\".\n" +
                "slash.\n" +
                "identifier,\"slash\".";

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Filtered Actual: [" + filteredActual + "]");
        System.out.println("Output length: " + filteredActual.length());

        assertEquals(expected, filteredActual);

        // Clean up
        boolean deleteResult = tempFile.delete();
        System.out.println("Temporary file deletion status: " + deleteResult);
    }

    @Test
    public void testLparenToken() throws IOException {
        output.reset();

        // Create a temporary file with the lparen token
        File tempFile = File.createTempFile("lparenToken", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("(");
        writer.close();

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim();

        // Expected output
        String expected = "lparen."; // Updated expected output

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testRparenToken() throws IOException {
        output.reset();

        // Print debug information before creating the temporary file
        System.out.println("Creating temporary file for rparen token test.");

        // Create a temporary file with the rparen token
        File tempFile = File.createTempFile("rparenToken", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write(")");
        writer.close();

        // Print debug information before passing the filename as an argument
        System.out.println("Passing the filename as an argument: " + tempFile.getAbsolutePath());

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Run the main method with the temporary file
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim();
        String expected = "rparen."; // Updated expected output

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.out.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testLsquareToken() throws IOException {
        output.reset();

        // Print debug information before creating the temporary file
        System.out.println("Creating temporary file for lsquare token test.");

        // Create a temporary file with the lsquare token
        File tempFile = File.createTempFile("lsquareToken", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("[");
        writer.close();

        // Verify that the temporary file has been created and contains the expected
        // content
        System.out.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.out.println(
                "Temporary file content: [" + new String(java.nio.file.Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Run the main method with the temporary file
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim();
        System.out.println("Captured output: [" + actual + "]");

        // Expected output
        String expected = "lsquare."; // Updated expected output
        System.out.println("Expected output: [" + expected + "]");

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.out.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testRsquareToken() throws IOException {
        output.reset();

        // Create a temporary file with the rsquare token
        File tempFile = File.createTempFile("rsquareToken", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("]");
        writer.close();

        // Debug: Print the file path and content before calling the main method
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture the output
        String actual = baos.toString().trim();
        String expected = "rsquare."; // Updated expected output

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testQuoteToken() throws IOException {
        output.reset();

        // Create a temporary file with the quote token
        File tempFile = File.createTempFile("quoteToken", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("\"");
        writer.close();

        // Debug: Print the path and content of the temporary file
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim();
        String expected = "error,\"\"\"."; // Updated expected output

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testSpecialCharacters() throws IOException {
        output.reset();

        // Create a temporary file with special characters
        File tempFile = File.createTempFile("specialChars", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("@#$%^&*");
        writer.close();

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Read the output
        String actual = output.toString().trim();
        String expected = "error,\"@#$%^&*\"."; // Updated expected output

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");

        assertEquals(expected, actual);

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testLongInputStream() throws IOException {
        output.reset();

        // Create a temporary file with a long input
        File tempFile = File.createTempFile("longInput", ".txt");
        StringBuilder longInput = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            longInput.append("a");
        }
        FileWriter writer = new FileWriter(tempFile);
        writer.write(longInput.toString());
        writer.close();

        // Print debug information about the file
        System.out.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.out.println("Temporary file content: " + new String(Files.readAllBytes(tempFile.toPath())));

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Read the captured output
        String actual = baos.toString().trim();
        String expected = "identifier,\"" + longInput.toString() + "\"."; // Updated expected output

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.out.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testEmptyInput() throws IOException {
        output.reset();

        // Create a temporary file with an empty input
        File tempFile = File.createTempFile("emptyInput", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("");
        writer.close();

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Read the output
        String actual = output.toString().trim();
        String expected = "";

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");

        assertEquals(expected, actual);

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testWhitespaceOnlyFile() throws IOException {
        output.reset();

        // Create a temporary file with only whitespace
        File tempFile = File.createTempFile("whitespaceFile", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write(" \t\n\r");
        writer.close();

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Capture the actual output
        String actual = output.toString().trim();
        String expected = "error,\"	\"."; // Updated expected output to include only the tab character

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testMixedWhitespaceAndCharacters() throws IOException {
        output.reset();

        // Create a temporary file with mixed whitespace and characters
        File tempFile = File.createTempFile("mixedFile", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("a b\tc\nd\re f");
        writer.close();

        // Print debug information about the file
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Read the output
        String actual = baos.toString().trim().replace("\r\n", "\n");
        String expected = "identifier,\"a\".\nerror,\"b\tc\".\nidentifier,\"d\".\nidentifier,\"e\".\nidentifier,\"f\".";

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");
        System.err.println("Output length: " + actual.length());

        assertEquals(expected, actual);

        // Clean up
        boolean deleteResult = tempFile.delete();
        System.err.println("Temporary file deletion status: " + deleteResult);
    }

    @Test
    public void testSpecialTokens() throws IOException {
        output.reset();

        // Create a temporary file with special tokens
        File tempFile = File.createTempFile("specialTokens", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("/* comment */ // line comment #hash");
        writer.close();

        // Print debug information about the file
        System.out.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.out.println("Temporary file content: " + new String(Files.readAllBytes(tempFile.toPath())));

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Read the output
        String actual = baos.toString().trim().replace("\r\n", "\n");
        String expected = "slash.\nerror,\"*\".\nidentifier,\"comment\".\nerror,\"*\".\nslash.\nslash.\nslash.\nidentifier,\"line\".\nidentifier,\"comment\".\nerror,\"#hash\".";

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");
        System.out.println("Output length: " + actual.length());

        assertEquals(expected, actual);

        // Clean up
        boolean deleteResult = tempFile.delete();
        System.out.println("Temporary file deletion status: " + deleteResult);
    }

    @Test
    public void testDifferentNewlineCharacters() throws IOException {
        output.reset();

        // Create a temporary file with different newline characters
        File tempFile = File.createTempFile("newlineFile", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("line1\r\nline2\nline3\r");
        writer.close();

        // Debug: Print the path and content of the temporary file
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim().replace("\r\n", "\n").replace("\r", "\n");
        String expected = "identifier,\"line1\".\nidentifier,\"line2\".\nidentifier,\"line3\".";

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testSingleSpecialCharacter() throws IOException {
        String[] specialCharacters = { "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "=", "+", "{", "}", "[",
                "]", "|", "\\", ":", ";", "\"", "'", "<", ">", ",", ".", "?", "/" };
        for (String character : specialCharacters) {
            output.reset();

            // Create a temporary file with a single special character
            File tempFile = File.createTempFile("singleSpecialChar", ".txt");
            FileWriter writer = new FileWriter(tempFile);
            writer.write(character);
            writer.close();

            // Debug: Print the path and content of the temporary file
            System.err.println("Testing character: " + character);
            System.err.println("Temporary file path: " + tempFile.getAbsolutePath());
            System.err.println("Temporary file content: ["
                    + new String(java.nio.file.Files.readAllBytes(tempFile.toPath())) + "]");

            // Capture the current System.out
            PrintStream originalOut = System.out;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintStream ps = new PrintStream(baos);
            System.setOut(ps);

            // Pass the filename as an argument
            String[] args = { tempFile.getAbsolutePath() };
            System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
            right_printtokens.main(args);

            // Restore the original System.out
            System.out.flush();
            System.setOut(originalOut);

            // Capture and print the actual output
            String actual = baos.toString().trim();

            // Determine the expected output based on the character
            String expected;
            switch (character) {
                case "(":
                    expected = "lparen.";
                    break;
                case ")":
                    expected = "rparen.";
                    break;
                case "[":
                    expected = "lsquare.";
                    break;
                case "]":
                    expected = "rsquare.";
                    break;
                case "'":
                    expected = "quote.";
                    break;
                case "/":
                    expected = "slash.";
                    break;
                case ";":
                    expected = "comment,\";\".";
                    break;
                case ",":
                    expected = "comma.";
                    break;
                default:
                    expected = "error,\"" + character + "\".";
                    break;
            }

            // Debug: Print the captured output
            System.err.println("Expected: [" + expected + "]");
            System.err.println("Actual: [" + actual + "]");

            // Assert the output
            assertEquals(expected, actual);

            // Clean up
            boolean deleted = tempFile.delete();
            System.err.println("Temporary file deleted: " + deleted);
        }
    }

    @Test
    public void testMixOfAlphanumericAndSpecialCharacters() throws IOException {
        output.reset();

        // Create a temporary file with a mix of alphanumeric and special characters
        File tempFile = File.createTempFile("mixedChars", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("abc123!@#");
        writer.close();

        // Debug: Print the path and content of the temporary file
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim();
        String expected = "error,\"abc123!@#\".";

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testEmptyLines() throws IOException {
        output.reset();

        // Create a temporary file with empty lines
        File tempFile = File.createTempFile("emptyLines", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("\n\n\n");
        writer.close();

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Read the output
        String actual = output.toString().trim();
        String expected = ""; // Assuming empty lines are ignored

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");

        assertEquals(expected, actual);

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testEscapeSequences() throws IOException {
        output.reset();

        // Create a temporary file with escape sequences
        File tempFile = File.createTempFile("escapeSequences", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("\\n \\t \\r \\b \\f");
        writer.close();

        // Debug: Print the file content and path
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: " + new String(Files.readAllBytes(tempFile.toPath())));

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Read the captured output
        String actual = baos.toString().trim().replace("\r\n", "\n");
        String expected = "error,\"\\n\".\nerror,\"\\t\".\nerror,\"\\r\".\nerror,\"\\b\".\nerror,\"\\f\".";

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testMixedCaseIdentifiers() throws IOException {
        output.reset();

        // Create a temporary file with mixed case identifiers
        File tempFile = File.createTempFile("mixedCaseIdentifiers", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("Var var VAR");
        writer.close();

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Read the captured output
        String actual = baos.toString().trim().replace("\r\n", "\n");
        String expected = "identifier,\"Var\".\nidentifier,\"var\".\nidentifier,\"VAR\".";

        // Debug information
        System.out.println("Expected: [" + expected + "]");
        System.out.println("Actual: [" + actual + "]");

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testStringsWithSpecialCharacters() throws IOException {
        output.reset();

        // Create a temporary file with strings containing special characters
        File tempFile = File.createTempFile("stringsWithSpecialCharacters", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("\"test@string#\"\n\"another$string%\"\n\"special^&*()characters\"");
        writer.close();

        // Debug: Print the path and content of the temporary file
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output for debugging
        String actual = baos.toString().trim().replace("\r\n", "\n");
        String expected = "string,\"test@string#\".\nstring,\"another$string%\".\nstring,\"special^&*()characters\".";

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testStringsWithEscapedQuotes() throws IOException {
        output.reset();

        // Create a temporary file with strings with escaped quotes
        File tempFile = File.createTempFile("stringsWithEscapedQuotes", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("\"test \\\"string\\\"\" \"another \\\"string\\\"\"");
        writer.close();

        // Print debug information about the file
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture and print the actual output
        String actual = baos.toString().trim().replace("\r\n", "\n");
        System.err.println("Captured output: [" + actual + "]");

        // Expected output
        String expected = "string,\"test \\\".\nerror,\"string\\\"\"\".\nstring,\"another \\\".\nerror,\"string\\\"\"\".";

        // Debug information
        System.err.println("Expected output: [" + expected + "]");
        System.err.println("Actual output: [" + actual + "]");

        // Assert the output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testKeywordsWithSpecialCharacters() throws IOException {
        output.reset();

        // Create a temporary file with keywords mixed with special characters
        File tempFile = File.createTempFile("keywordsWithSpecialCharacters", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("and@ or# if$ xor% lambda^ =>&");
        writer.close();

        // Debug: Print the file content and path
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: " + new String(Files.readAllBytes(tempFile.toPath())));

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Read the captured output
        String actual = baos.toString().trim().replace("\r\n", "\n");
        String expected = "error,\"and@\".\nerror,\"or#\".\nerror,\"if$\".\nerror,\"xor%\".\nerror,\"lambda^\".\nerror,\"=>&\".";

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the expected output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testCommentLinesWithDifferentMarkers() throws IOException {
        output.reset();

        // Create a temporary file with comment lines with different markers
        File tempFile = File.createTempFile("commentLinesWithDifferentMarkers", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("; comment 1\n// comment 2\n# comment 3");
        writer.close();

        // Print debug information about the file
        System.err.println("Temporary file created at: " + tempFile.getAbsolutePath());
        System.err.println("Temporary file content: [" + new String(Files.readAllBytes(tempFile.toPath())) + "]");

        // Capture the current System.out
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);

        // Pass the filename as an argument
        String[] args = { tempFile.getAbsolutePath() };
        System.err.println("Calling right_printtokens.main with args: " + String.join(", ", args));
        right_printtokens.main(args);

        // Restore the original System.out
        System.out.flush();
        System.setOut(originalOut);

        // Capture the output
        String actual = baos.toString().trim().replace("\r\n", "\n");
        String expected = "comment,\"; comment 1\".\nslash.\nslash.\nidentifier,\"comment\".\nnumeric,2.\nerror,\"#\".\nidentifier,\"comment\".\nnumeric,3.";

        // Debug information
        System.err.println("Expected: [" + expected + "]");
        System.err.println("Actual: [" + actual + "]");

        // Assert the output
        assertEquals(expected, actual);

        // Clean up
        boolean deleted = tempFile.delete();
        System.err.println("Temporary file deleted: " + deleted);
    }

    @Test
    public void testOpenCharacterStreamWithNull() throws IOException {
        // Test with null argument
        BufferedReader br = ob.open_character_stream(null);
        assertNotNull(br);
        br.close();
    }

    @Test
    public void testOpenCharacterStreamWithEmptyString() throws IOException {
        // Test with empty string argument
        BufferedReader br = ob.open_character_stream("");
        assertNotNull(br);
        br.close();
    }

    @Test
    public void testOpenCharacterStreamWithNonExistentFile() {
        // Test with non-existent file
        BufferedReader br = ob.open_character_stream("nonexistentfile.txt");
        assertNull(br);
    }

    @Test
    public void testOpenCharacterStreamWithValidFile() throws IOException {
        // Create a temporary file for testing
        File tempFile = File.createTempFile("testfile", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("test content");
        writer.close();

        // Test with valid file
        BufferedReader br = ob.open_character_stream(tempFile.getAbsolutePath());
        assertNotNull(br);
        br.close();

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testGetChar() throws IOException {
        StringReader temp = new StringReader("test");
        BufferedReader br = new BufferedReader(temp);
        try {
            assertEquals('t', ob.get_char(br));
            assertEquals('e', ob.get_char(br));
            assertEquals('s', ob.get_char(br));
            assertEquals('t', ob.get_char(br));
            assertEquals(-1, ob.get_char(br)); // EOF
        } catch (Exception e) {
            // Handle the exception without printing stack trace
        }
    }

    @Test
    public void testUngetChar() throws IOException {
        StringReader temp = new StringReader("test");
        BufferedReader br = new BufferedReader(temp);
        try {
            assertEquals('t', ob.get_char(br));
            assertEquals('e', ob.get_char(br));
            ob.unget_char('e', br);
            assertEquals('e', ob.get_char(br)); // Should read 'e' again after unget
        } catch (Exception e) {
            // Handle the exception without printing stack trace
        }
    }

    @Test
    public void testOpenTokenStreamWithNull() throws IOException {
        // Test with null argument
        BufferedReader br = ob.open_token_stream(null);
        assertNotNull(br);
        br.close();
    }

    @Test
    public void testOpenTokenStreamWithEmptyString() throws IOException {
        // Test with empty string argument
        BufferedReader br = ob.open_token_stream("");
        assertNotNull(br);
        br.close();
    }

    @Test
    public void testOpenTokenStreamWithNonExistentFile() {
        // Test with non-existent file
        BufferedReader br = ob.open_token_stream("nonexistentfile.txt");
        assertNull(br);
    }

    @Test
    public void testOpenTokenStreamWithValidFile() throws IOException {
        // Create a temporary file for testing
        File tempFile = File.createTempFile("testfile", ".txt");
        FileWriter writer = new FileWriter(tempFile);
        writer.write("test content");
        writer.close();

        // Test with valid file
        BufferedReader br = ob.open_token_stream(tempFile.getAbsolutePath());
        assertNotNull(br);
        br.close();

        // Clean up
        tempFile.delete();
    }

    @Test
    public void testGetTokenWithEmptyString() {
        StringReader temp = new StringReader("");
        BufferedReader br = new BufferedReader(temp);
        assertEquals(null, ob.get_token(br));
    }

    @Test
    public void testGetTokenWithTab() {
        StringReader temp = new StringReader("\t");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("\t", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithNewLine() {
        StringReader temp = new StringReader("\n");
        BufferedReader br = new BufferedReader(temp);
        assertEquals(null, ob.get_token(br));
    }

    @Test
    public void testGetTokenWithCarriageReturn() {
        StringReader temp = new StringReader("\r");
        BufferedReader br = new BufferedReader(temp);
        assertEquals(null, ob.get_token(br));
    }

    @Test
    public void testGetTokenWithLParen() {
        StringReader temp = new StringReader("(");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("(", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithNewLineAndChar() {
        StringReader temp = new StringReader("\na");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("a", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithSemiColon() {
        StringReader temp = new StringReader(";");
        BufferedReader br = new BufferedReader(temp);
        assertEquals(";", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithQuote() {
        StringReader temp = new StringReader("\"");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("\"", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithAlphaNumeric() {
        StringReader temp = new StringReader("AB ");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("AB", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithAlphaNumericSequence() {
        StringReader temp = new StringReader("ABC");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("ABC", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithAlphaNumericAndParen() {
        StringReader temp = new StringReader("ABC(");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("ABC", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithAlphaNumericAndQuote() {
        StringReader temp = new StringReader("ABC\"");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("ABC\"", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithAlphaNumericAndSemiColon() {
        StringReader temp = new StringReader("ABC;");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("ABC", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithAlphaNumericOnly() {
        StringReader temp = new StringReader("ABC");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("ABC", ob.get_token(br));
    }

    @Test
    public void testGetTokenWithQuotedString() {
        StringReader temp = new StringReader("\"ABC\"");
        BufferedReader br = new BufferedReader(temp);
        assertEquals("\"ABC\"", ob.get_token(br));
    }

    @Test
    public void testIsTokenEnd() {
        // Testing with state 0 (start state)
        assertEquals(true, right_printtokens.is_token_end(0, -1), "State 0, char -1 should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 10), "State 0, char 10 (newline) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 13),
                "State 0, char 13 (carriage return) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 32), "State 0, char 32 (space) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 40),
                "State 0, char 40 (open parenthesis) should be token end");
        assertEquals(true, right_printtokens.is_token_end(0, 59), "State 0, char 59 (semicolon) should be token end");
        assertEquals(false, right_printtokens.is_token_end(0, 69), "State 0, char 69 should not be token end");

        // Testing with state 1 (inside token state)
        assertEquals(true, right_printtokens.is_token_end(1, 34),
                "State 1, char 34 (double quote) should be token end");
        assertEquals(true, right_printtokens.is_token_end(1, 10), "State 1, char 10 (newline) should be token end");
        assertEquals(true, right_printtokens.is_token_end(1, 13),
                "State 1, char 13 (carriage return) should be token end");
        assertEquals(false, right_printtokens.is_token_end(1, 67), "State 1, char 67 should not be token end");

        // Testing with state 2 (inside string state)
        assertEquals(true, right_printtokens.is_token_end(2, 10), "State 2, char 10 (newline) should be token end");
        assertEquals(true, right_printtokens.is_token_end(2, 13),
                "State 2, char 13 (carriage return) should be token end");
        assertEquals(true, right_printtokens.is_token_end(2, 9), "State 2, char 9 (tab) should be token end");
        assertEquals(false, right_printtokens.is_token_end(2, 68), "State 2, char 68 should not be token end");

        assertEquals(false, right_printtokens.is_token_end(0, 0),
                "State 0, char 0 (null character) should not be token end");
        assertEquals(false, right_printtokens.is_token_end(1, 48), "State 1, char 48 (number) should not be token end");
        assertEquals(false, right_printtokens.is_token_end(2, 65), "State 2, char 65 (letter) should not be token end");
    }

    @Test
    public void testIsKeyword() {
        assertEquals(true, right_printtokens.is_keyword("and"));
        assertEquals(true, right_printtokens.is_keyword("or"));
        assertEquals(true, right_printtokens.is_keyword("if"));
        assertEquals(true, right_printtokens.is_keyword("xor"));
        assertEquals(true, right_printtokens.is_keyword("lambda"));
        assertEquals(true, right_printtokens.is_keyword("=>"));
        assertEquals(false, right_printtokens.is_keyword("software"));
    }

    @Test
    public void testIsNumConstant() {
        assertEquals(false, right_printtokens.is_num_constant("a"));
        assertEquals(false, right_printtokens.is_num_constant("1A"));
        assertEquals(true, right_printtokens.is_num_constant("123"));
        assertEquals(true, right_printtokens.is_num_constant("1"));
        assertEquals(true, right_printtokens.is_num_constant("321\0"));
    }

    @Test
    public void testIsStrConstant() {
        assertEquals(false, right_printtokens.is_str_constant("21"));
        assertEquals(true, right_printtokens.is_str_constant("\"\""));
        assertEquals(true, right_printtokens.is_str_constant("\"cse\"\0"));
        assertEquals(false, right_printtokens.is_str_constant("\"D"));
        assertEquals(false, right_printtokens.is_str_constant("\"S\0"));
        assertEquals(false, right_printtokens.is_str_constant("\""));
    }

    @Test
    public void testIsIdentifier() {
        assertEquals(false, right_printtokens.is_identifier("1"));
        assertEquals(false, right_printtokens.is_identifier("a!"));
        assertEquals(true, right_printtokens.is_identifier("aa"));
        assertEquals(true, right_printtokens.is_identifier("a1\0"));
    }

    @Test
    public void testTokenType() {
        assertEquals(right_printtokens.keyword, right_printtokens.token_type("and"));
        assertEquals(right_printtokens.spec_symbol, right_printtokens.token_type("("));
        assertEquals(right_printtokens.identifier, right_printtokens.token_type("var123"));
        assertEquals(right_printtokens.num_constant, right_printtokens.token_type("123"));
        assertEquals(right_printtokens.str_constant, right_printtokens.token_type("\"str\""));
        assertEquals(right_printtokens.char_constant, right_printtokens.token_type("#a"));
        assertEquals(right_printtokens.comment, right_printtokens.token_type("; comment"));
        assertEquals(right_printtokens.error, right_printtokens.token_type("!@#"));
    }

    @Test
    public void testPrintToken() {
        // Redirect System.out for testing
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        ob.print_token("and");
        assertEquals("keyword,\"and\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("(");
        assertEquals("lparen.", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("var123");
        assertEquals("identifier,\"var123\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("123");
        assertEquals("numeric,123.", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("\"str\"");
        assertEquals("string,\"str\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("#a");
        assertEquals("character,\"a\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("; comment");
        assertEquals("comment,\"; comment\".", outContent.toString().trim());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ob.print_token("!@#");
        assertEquals("error,\"!@#\".", outContent.toString().trim());
    }

    @Test
    public void testPrintSpecSymbol() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        right_printtokens.print_spec_symbol("(");
        assertEquals("lparen.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol(")");
        assertEquals("rparen.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("[");
        assertEquals("lsquare.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("]");
        assertEquals("rsquare.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("'");
        assertEquals("quote.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("/");
        assertEquals("slash.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol("`");
        assertEquals("bquote.", outContent.toString().trim());

        outContent.reset();
        right_printtokens.print_spec_symbol(",");
        assertEquals("comma.", outContent.toString().trim());
    }

    @Test
    public void testIsSpecSymbol() {
        assertTrue(right_printtokens.is_spec_symbol('('));
        assertTrue(right_printtokens.is_spec_symbol(')'));
        assertTrue(right_printtokens.is_spec_symbol('['));
        assertTrue(right_printtokens.is_spec_symbol(']'));
        assertTrue(right_printtokens.is_spec_symbol('\''));
        assertTrue(right_printtokens.is_spec_symbol('`'));
        assertTrue(right_printtokens.is_spec_symbol(','));
        assertTrue(right_printtokens.is_spec_symbol('/'));
        assertFalse(right_printtokens.is_spec_symbol('a'));
        assertFalse(right_printtokens.is_spec_symbol('1'));
    }
}